#import "GPUImageTwoInputFilter.h"

@interface GPUImageHueBlendFilter : GPUImageTwoInputFilter

@end
